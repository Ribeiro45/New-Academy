-- Primeiro: apenas adicionar o novo valor ao enum
ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'lider';